﻿using System;
using System.Activities.Statements;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class adminkey2hcomindex : System.Web.UI.Page
{


    ClientdashboardIssue CI=new ClientdashboardIssue();
    ClientUsers CU = new ClientUsers();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Loginbtn_Click(object sender, EventArgs e)
    {
        string labelerror = string.Empty;

        if (string.IsNullOrEmpty(txtusername.Text) && string.IsNullOrEmpty(txtpassword.Text))
        {
            labelerror = "Fill all the field";
        }
        else if (string.IsNullOrEmpty(txtusername.Text))
        {
            labelerror = "Enter name";
        }
        else if (string.IsNullOrEmpty(txtpassword.Text))
        {
            labelerror = "Enter password";
        }

        if (string.IsNullOrEmpty(labelerror))
        {

            try
            {

                CU.username = txtusername.Text.Trim();
                CU.password = txtpassword.Text.Trim();
                DataTable dt = CU.ViewValidClientUserLogin(CU);
                if (dt.Rows.Count > 0)
                {

                    if (Convert.ToBoolean(dt.Rows[0]["UserStatus"]) ==true)
                    {
                        string username = Convert.ToString(dt.Rows[0]["UserName"]);
                        string password = Convert.ToString(dt.Rows[0]["Password"]);
                        int strclientID = Convert.ToInt32(dt.Rows[0]["ClientID"]);
                        string strEmailid = Convert.ToString(dt.Rows[0]["UserEmailID"]);
                        StringComparer ordCmp = StringComparer.Ordinal;
                        if (string.Equals(password, txtpassword.Text.Trim(), StringComparison.Ordinal) && string.Equals(username, txtusername.Text.Trim(), StringComparison.Ordinal))
                        {
                            CreateCookies(txtusername.Text.Trim(), strclientID,strEmailid);
                            FormsAuthentication.SetAuthCookie(txtusername.Text.Trim(), true);
                            Response.Redirect("add-project.aspx", false);
                            HttpContext.Current.ApplicationInstance.CompleteRequest();
                        }
                        else
                        {
                            txtusername.Text = "";
                            labelerror = "Invalid Username and Password";
                            ShowInvalidLoginAlert(labelerror);
                        }
                    }
                    else
                    {
                        labelerror = "Client is not active, pls contact your admin";
                        ShowInvalidLoginAlert(labelerror);
                    }
                }
                else
                {
                    txtusername.Text = "";
                    labelerror = "Invalid Username and Password";
                    ShowInvalidLoginAlert(labelerror);
                }
            }
            catch (Exception ex)
            {

                CI.Pagename = "Index.aspx";
                CI.MethodOrFunctionname = "Loginbtn_Click";
                CI.ErrrMsg = ex.Message.ToString();
                CI.IssueStatus = "Not Fixed";
                CI.AddClientdashboardissues(CI);
            }
        }
        else
        {

            ShowInvalidLoginAlert(labelerror);
        }
        

    }



    private void ShowInvalidLoginAlert(string LABELERROR)
    {

        // JavaScript for SweetAlert
        string script = @"
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
    <script>
        Swal.fire({
            title: 'Alert',
            text: '" + LABELERROR + @"',
            icon: 'warning',
            confirmButtonText: 'OK',
            customClass: {
                popup: 'swal-popup',
                title: 'swal-title',
                content: 'swal-content' 
            }
        }).then(function() { 
        });
    </script>";

        // CSS to change text color, popup width, and button style
        string css = @"
    <style>
        .swal-content { color: yellow !important; }  
        .swal-popup { width: 300px !important; }  
        .swal-title { font-size: 22px !important; }    
    </style>";

        // Register JavaScript and CSS
        Page.ClientScript.RegisterStartupScript(this.GetType(), "SweetAlertCSS", css);
        Page.ClientScript.RegisterStartupScript(this.GetType(), "SweetAlert", script);


    }



    public void CreateCookies(string strUsername, int ClientID,string strEmailID)
    {
        if (Request.Browser.Cookies)
        {
            HttpCookie LoginCookie = Request.Cookies["CLIENTDASHBOARDLOGIN"];
            HttpCookie EmailidCookie = Request.Cookies["EmailID"];
            HttpCookie LoginIDCookie = Request.Cookies["clientid"];
            HttpCookie UsernameCookie = Request.Cookies["Username"];

            if (LoginCookie == null)
            {
                LoginCookie = new HttpCookie("CLIENTDASHBOARDLOGIN");
            }
            if (EmailidCookie == null)
            {
                EmailidCookie = new HttpCookie("EmailID");
            }
            if (LoginIDCookie == null)
            {
                LoginIDCookie = new HttpCookie("clientid");
            } 
            
            if (UsernameCookie == null)
            {
                UsernameCookie = new HttpCookie("Username");
            }

            LoginCookie["CLIENTDASHBOARDLOGIN"] = strUsername.Trim();
            LoginIDCookie["clientid"] = Convert.ToString(ClientID);
            EmailidCookie["EmailID"] = Convert.ToString(strEmailID);
            UsernameCookie["Username"] = Convert.ToString(strUsername);

            Response.Cookies.Add(LoginCookie);
            Response.Cookies.Add(EmailidCookie);
            Response.Cookies.Add(LoginIDCookie);
            Response.Cookies.Add(UsernameCookie);
        }

        Session["CLIENTDASHBOARDLOGIN"] = strUsername.Trim();
        Session["clientid"] = ClientID;

    }


}