﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Net.NetworkInformation;
using System.Drawing;
using System.IdentityModel.Protocols.WSTrust;


public partial class adminkey2hcom_flat : System.Web.UI.Page
{
    Key2hFlat KF = new Key2hFlat();
    Key2hProjectblock KB = new Key2hProjectblock();
    DataTable dt1 = new DataTable();
    DataRow dr1;


    Key2hProject K2 = new Key2hProject();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Bind();

            DataTable dt = K2.ViewAllProjects("All", "All", "All");
            if (dt.Rows.Count > 0)
            {
                ddlprojects.DataSource = dt;
                ddlprojects.DataTextField = "ProjectName";
                ddlprojects.DataValueField = "ProjectID";
                ddlprojects.DataBind();
                ddlprojects.Items.Insert(0, new ListItem("All", ""));
            }
            else
            {
                ddlprojects.Items.Insert(0, new ListItem("", ""));
                ddlprojects.Items.Insert(2, new ListItem("No Projects", ""));
            }
        }
    }



    public string Bindcity(int ID)
    {
        string city = string.Empty;
        DataTable dt = K2.ViewcityByCityid(ID);
        if (dt.Rows.Count > 0)
        {
            city = dt.Rows[0]["CityName"].ToString();
        }

        return city;
    }


    public string Bindproject(int ID)
    {
        string Project = string.Empty;
        DataTable dt = K2.ViewAllProjectsByid(ID);
        if (dt.Rows.Count > 0)
        {
            Project = dt.Rows[0]["ProjectName"].ToString();
        }

        return Project;
    }  
    
    
    public string BindBlockname(int ID)
    {
        string Block = string.Empty;
        DataTable dt = KB.ViewAllBlock(Convert.ToString(ID), "", "");
        if (dt.Rows.Count > 0)
        {
            Block = dt.Rows[0]["BlockName"].ToString();
        }

        return Block;
    }


    public void Bind()
    {
        DataTable dt = Get();
        if (dt.Rows.Count > 0)
        {
            rpruser.Visible = true;
            rpruser.DataSource = dt;
            Session["Flat"] = dt.DefaultView;
            lblcount.Text = Convert.ToString(dt.Rows.Count);
            rpruser.DataBind();
            DivNoDataFound.Style.Add("display", "none");
            h5TotalNoCount.Style.Add("display", "block");

        }
        else
        {
            Session["Flat"] = null;
            rpruser.Visible = false;
            lblcount.Text = "0";
            DivNoDataFound.Style.Add("display", "block !important");
            h5TotalNoCount.Style.Add("display", "none");

        }

    }


    public DataTable Get()
    {


        string projectid = string.Empty;
        string prostatus = string.Empty;

        string status = string.Empty;
        if (!string.Equals(ddldisplaystatus.SelectedValue, "All"))
        {
            if (string.Equals(ddldisplaystatus.SelectedValue, "1"))
            {
                status = "1";
            }
            else
            {
                status = "0";
            }
        }
      
        if (!string.Equals(ddlprojects.SelectedValue, "All"))
        {
            projectid = ddlprojects.SelectedValue;
        }
               
        
        DataTable dt = KF.ViewAllBflat("", status, prostatus, projectid);

        return dt;
    }



    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "Edit")
        {
            try
            {
                int ID = Convert.ToInt32(e.CommandArgument);
                Response.Redirect("add-Flat.aspx?FlatID=" + ID, false);
                HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
            catch (Exception ex)
            {
            }
        }
        else if (e.CommandName == "Delete")
        {
            try
            {
                int ID = Convert.ToInt32(e.CommandArgument);


                int ret = 0;
               
               ret= KF.DeleteFlatbyflatID(ID);
                if (ret == 1)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                       "Swal.fire({ " +
                       "  title: 'Deleted Successfully', " +
                       "  text: 'Your flat has been successfully deleted.', " +
                       "  icon: 'success', " +
                       "  confirmButtonText: 'OK' " +
                       "}).then((result) => { " +
                       "  if (result.isConfirmed) { " +
                       "    window.location = 'view-flat.aspx'; " + // Replace with your target page URL
                       "  } " +
                       "});", true);
                }
            }
            catch (Exception ex)
            {
            }
          

        }
    }






    protected string GetRowNo(string itemIndex)
    {
        return PageIndex > 1 ? (((PageIndex - 1) * 10) + Convert.ToInt32(itemIndex)).ToString() : itemIndex;
    }


    public int PageIndex
    {
        get { return ViewState["PageIndex"] != null ? (int)ViewState["PageIndex"] : 1; }
        set { ViewState["PageIndex"] = value; }
    }

    protected void lnkbtngo_Click(object sender, EventArgs e)
    {
        Bind();
    }

    protected void lnkcancel_Click(object sender, EventArgs e)
    {
        ddldisplaystatus.SelectedIndex = 0;
        ddlprojects.SelectedIndex = 0;
      //  ddlprojectstatus.SelectedIndex = 0;
        Bind();
    }

    protected void ddlprojects_SelectedIndexChanged(object sender, EventArgs e)
    {
        Bind();
    }

    protected void ddldisplaystatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        Bind();
    }

    protected void ddlprojectstatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        Bind();
    }






    protected void btnSubmitExport_Click(object sender, EventArgs e)
    {
        DataView LoanTable = new DataView();
        try
        {
            LoanTable = ((DataView)Session["Flat"]);
            if (LoanTable != null && LoanTable.Count > 0)
            {
                DownloadToExcel();
            }
            else
            {
                string script = "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>" +
                                "<script>" +
                                "Swal.fire({" +
                                "title: 'No Records Found!'," +
                                "text: 'There are no records to export.'," +
                                "icon: 'warning'," +
                                "confirmButtonText: 'OK'" +
                                "});" +
                                "</script>";

                Page.ClientScript.RegisterStartupScript(this.GetType(), "SweetAlert", script);
            }
        }
        catch (Exception ex)
        {
        }
    }
    public void DownloadToExcel()
    {
        DataView LoanTable = new DataView();
        try
        {
            LoanTable = ((DataView)Session["Flat"]);
            if (LoanTable != null && LoanTable.Count > 0)
            {
                DataTable dt = new DataTable();
                dt = LoanTable.ToTable();
                dt1.Columns.Add("Sno");
                dt1.Columns.Add("Project Name");
                dt1.Columns.Add("Block no.");
                dt1.Columns.Add("Flat no. / Unit no.");
                dt1.Columns.Add("Facing");
                dt1.Columns.Add("UDS");
               // dt1.Columns.Add("Display Status");
                dt1.Columns.Add("No. of Flats / Units");
                dt1.Columns.Add("Added on");





                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {

                    dr1 = dt1.NewRow();
                    string sno = (i + 1).ToString();
                    dr1["Sno"] = sno;
                    dr1["Project Name"] = Bindproject(Convert.ToInt32(dt.Rows[i]["ProjectID"]));
                    dr1["Block no."] = BindBlockname(Convert.ToInt32(dt.Rows[i]["BlockID"]));
                    dr1["Flat no. / Unit no."] = dt.Rows[i]["FlatName"].ToString();
                   
                    dr1["Facing"] =dt.Rows[i]["Facing"].ToString();
                    dr1["UDS"] = dt.Rows[i]["UDS"].ToString();
                   
                   
                    DateTime dtDate = Convert.ToDateTime(dt.Rows[i]["Addeddate"]);
                    dr1["Added On"] = dtDate.ToString("dd/MM/yyyy");
                    dt1.Rows.Add(dr1);
                }
                ExportExcel(dt1);
            }
        }
        catch (Exception ex)
        {
        }
    }
    void ExportExcel(DataTable dt)
    {
        Response.ClearContent();
        Response.AddHeader("content-disposition", "attachment; filename=Flat_Details" + DateTime.Now.ToString("ddMMyyyy_hh:mm:ss") + ".xls");
        Response.ContentType = "application/ms-excel";
        string tab = "";
        foreach (DataColumn dc in dt.Columns)
        {
            Response.Write(tab + dc.ColumnName);
            tab = "\t";
        }
        Response.Write("\n");
        int i;
        foreach (DataRow dr in dt.Rows)
        {
            tab = "";
            for (i = 0; i < dt.Columns.Count; i++)
            {
                Response.Write(tab + dr[i].ToString());
                tab = "\t";
            }
            Response.Write("\n");
        }
        Response.End();

    }

     


}