﻿using System;
using System.Collections.Generic;
using System.Data;
using System.EnterpriseServices.CompensatingResourceManager;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class adminkey2hcom_AddBlock : System.Web.UI.Page
{

    Key2hProject k2 = new Key2hProject();
    Key2hProjectblock K2b = new Key2hProjectblock();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            Bindprojects();

            if (Request.QueryString["BlockID"] != null)
            {
                lbldisplaytext.Text = "Edit Block";
                btnSave.Text = "Update";
                Bind(Convert.ToString(Request.QueryString["BlockID"]));
            }
            else
            {
                btnSave.Text = "Submit";
                lbldisplaytext.Text = "Add Block";
            }
        }

    }

    public void Bind(string id)
    {

        DataTable DT = K2b.ViewAllBlock(id, "", "");


        if (DT.Rows.Count > 0)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(DT.Rows[0]["ProjectID"])))
            {
                ddlprojects.SelectedValue = Convert.ToString(DT.Rows[0]["ProjectID"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(DT.Rows[0]["BlockName"])))
            {
                txtBlockNumber.Text = Convert.ToString(DT.Rows[0]["BlockName"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(DT.Rows[0]["BlockStatus"])))
            {
                bool val = Convert.ToBoolean(DT.Rows[0]["BlockStatus"]);

                if (val == true)
                {
                    toggleActiveInactive.Checked = true;
                }
                else
                {
                    toggleActiveInactive.Checked = false;
                }
            }

        }


    }


    public void Bindprojects()
    {
        DataTable dt = k2.ViewActiveprojects();
        if (dt.Rows.Count > 0)
        {
            ddlprojects.DataSource = dt;
            ddlprojects.DataTextField = "ProjectName";
            ddlprojects.DataValueField = "ProjectID";
            ddlprojects.DataBind();
            ddlprojects.Items.Insert(0, new ListItem("", ""));
        }
    }



    protected void btnSave_Click(object sender, EventArgs e)
    {
        string Labelerror = string.Empty;

        if (string.IsNullOrEmpty(ddlprojects.SelectedValue) && string.IsNullOrEmpty(txtBlockNumber.Text))
        {
            Labelerror = "Fill all the field";
        }
        else if (string.IsNullOrEmpty(ddlprojects.SelectedValue))
        {
            Labelerror = "Select project";
        }
        else if (string.IsNullOrEmpty(txtBlockNumber.Text))
        {
            Labelerror = "Enter block number";
        }
        if (string.IsNullOrEmpty(Labelerror))
        {

            if (Request.QueryString["BlockID"] == null)
            {
                if (!Isalreadyexist(ddlprojects.SelectedValue, txtBlockNumber.Text))
                {
                    if (Addblock() == 1)
                    {



                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                        "Swal.fire('Added Successfully', 'Your block details have been successfully added!.', 'success');", true);

                        Clear();

                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
              "Swal.fire('Error', 'An error occurred while adding the details. Please try again.', 'error');", true);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                        "Swal.fire({ " +
                         "  title: 'Block Number Already Exists', " +
                         "  text: 'A block number with the same details already exists. Please check and try again.', " +
                         "  icon: 'warning', " +
                         "  confirmButtonText: 'OK', " +
                         "  confirmButtonColor: '#3085d6' " +
                         "});", true);
                }
            }
            else
            {
                if (Updateblock() == 1)
                {


                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                    "Swal.fire({title: 'Updated Successfully', text: 'Your block number have been successfully updated!', icon: 'success'}).then((result) => { if (result.isConfirmed) { window.location.href = 'view-block.aspx'; } });",
                     true);
                    Clear();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
          "Swal.fire('Error', 'An error occurred while adding the details. Please try again.', 'error');", true);
                }
            }
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
          "Swal.fire('Alert', 'An error occurred while adding the details. Please try again.', 'exist');", true);
        }

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();

        if (Request.QueryString["BlockID"] == null)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                  "Swal.fire('Cancelled!', 'Your action has been canceled.', 'success');",
                  true);
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
            "Swal.fire({title: 'Cancelled', text: 'Your action has been canceled.', icon: 'success'}).then((result) => { if (result.isConfirmed) { window.location.href = 'add-block.aspx'; } });",
             true);
        }
    }



    public bool Isalreadyexist(string PID, string Bname)
    {
        bool isavail = false;
        string strbname = string.Empty;
        DataTable dt = K2b.BlockAlreadyExistByProjectid(Convert.ToInt32(PID), Bname);

        if (dt.Rows.Count > 0)
        {
           
                isavail = true;
            
        }

        return isavail;
    }


    public int Addblock()
    {
        K2b.ProjectID = Convert.ToInt32(ddlprojects.SelectedValue);
        K2b.Blocknumber = txtBlockNumber.Text;
        K2b.Status = toggleActiveInactive.Checked;
        K2b.Addedby = "Admin";
        int ret = 0;
        ret = K2b.Addblocks(K2b);
        return ret;
    }

    public int Updateblock()
    {

        K2b.BlcokID = Convert.ToInt32(Request.QueryString["BlockID"]);
        K2b.ProjectID = Convert.ToInt32(ddlprojects.SelectedValue);
        K2b.Blocknumber = txtBlockNumber.Text;
        K2b.Status = toggleActiveInactive.Checked;
        K2b.Addedby = "Admin";
        int ret = 0;
        ret = K2b.Updateblock(K2b);
        return ret;
    }



    public void Clear()
    {
        txtBlockNumber.Text = "";
        ddlprojects.SelectedValue = "";
        toggleActiveInactive.Checked = true;
    }

}