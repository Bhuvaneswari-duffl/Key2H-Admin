﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_add_block : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {

        // Retrieve the connection string from the web.config file
        string connectionString = ConfigurationManager.ConnectionStrings["MyDatabase"].ConnectionString;

        // Create an instance of BlockDetails
        BlockDetails blockDetails = new BlockDetails(
            ddlProName.SelectedItem.Text,    // ProjectName
            txtBlockNumber.Text,             // BlockNumber
            "Admin"                          // AddedBy
        );

        // Try to save the block details to the database
        bool success = blockDetails.SaveToDatabase(connectionString);

        // Display success or error message
        if (success)
        {
            // Success SweetAlert and reset form fields
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
            "Swal.fire('Added Successfully', 'Your Block details have been successfully added!', 'success').then(() => { " +
                "document.getElementById('" + ddlProName.ClientID + "').selectedIndex = 0; " + // Reset DropdownList
                "document.getElementById('" + txtBlockNumber.ClientID + "').value = ''; " +  // Clear TextBox
            "});", true);
        }
        else
        {
            // Error SweetAlert
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
            "Swal.fire('Error', 'An error occurred while adding the details. Please try again.', 'error');", true);
        }
    }

}