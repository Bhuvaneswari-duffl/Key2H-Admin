﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Net.NetworkInformation;
using System.Drawing;

public partial class adminkey2hcom_ViewProjects : System.Web.UI.Page
{

    DataTable dt1 = new DataTable();
    DataRow dr1;


    Key2hProject K2 = new Key2hProject();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Bind();

            DataTable dt = K2.ViewAllProjects("All", "All", "All");
            if (dt.Rows.Count > 0)
            {
                ddlprojects.DataSource = dt;
                ddlprojects.DataTextField = "ProjectName";
                ddlprojects.DataValueField = "ProjectID";
                ddlprojects.DataBind();
                ddlprojects.Items.Insert(0, new ListItem("All", ""));
            }
            else
            {
                ddlprojects.Items.Insert(0, new ListItem("", ""));
                ddlprojects.Items.Insert(2, new ListItem("No Projects", ""));
            }
        }
    }



    public string Bindcity(int ID)
    {
        string city = string.Empty;
        DataTable dt = K2.ViewcityByCityid(ID);
        if (dt.Rows.Count > 0)
        {
            city = dt.Rows[0]["CityName"].ToString();
        }

        return city;
    }


    public string BindState(int ID)
    {
        string city = string.Empty;
        DataTable dt = K2.ViewstateByID(ID);
        if (dt.Rows.Count > 0)
        {
            city = dt.Rows[0]["StateName"].ToString();
        }

        return city;
    }


    public void Bind()
    {
        DataTable dt = Get();
        if (dt.Rows.Count > 0)
        {
            rpruser.Visible = true;
            rpruser.DataSource = dt;
            Session["Projects"] = dt.DefaultView;
            lblcount.Text = Convert.ToString(dt.Rows.Count);
            rpruser.DataBind();
            DivNoDataFound.Style.Add("display", "none");
            h5TotalNoCount.Style.Add("display", "block");

        }
        else
        {
            Session["Projects"] = null;
            rpruser.Visible = false;
            lblcount.Text = "0";
            DivNoDataFound.Style.Add("display", "block");
            h5TotalNoCount.Style.Add("display", "none");

        }

    }


    public DataTable Get()
    {


        string projectid = string.Empty;
        string prostatus = string.Empty;

        string status = string.Empty;
        if (!string.Equals(ddldisplaystatus.SelectedValue, "All"))
        {
            if (string.Equals(ddldisplaystatus.SelectedValue, "1"))
            {
                status = "1";
            }
            else
            {
                status = "0";
            }
        }
        else if (!string.Equals(ddlprojectstatus.SelectedValue, "All"))
        {
            prostatus = ddlprojectstatus.SelectedValue;
        }
        else if (!string.Equals(ddlprojects.SelectedValue, "All"))
        {
            projectid = ddlprojects.SelectedValue;
        }

        DataTable dt = K2.ViewAllProjects(projectid, status, prostatus);

        return dt;
    }



    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "Edit")
        {
            try
            {
                int ID = Convert.ToInt32(e.CommandArgument);
                Response.Redirect("add-project.aspx?ProjectID=" + ID, false);
                HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
            catch (Exception ex)
            {
            }
        }
        else if (e.CommandName == "Delete")
        {
            try
            {
                int ID = Convert.ToInt32(e.CommandArgument);


                DataTable dt = K2.ViewAllProjectsByid(ID);
                if (dt.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["ProjectLogo"])))
                    {
                        String strlogo = Convert.ToString(dt.Rows[0]["ProjectLogo"]);
                        FileDelete(strlogo, "Logo");
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["SplashScreenImage"])))
                    {
                        string strscreenimage = Convert.ToString(dt.Rows[0]["SplashScreenImage"]);
                        FileDelete(strscreenimage, "ProjectScreen");
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["LocationMap"])))
                    {
                        string strMap = Convert.ToString(dt.Rows[0]["LocationMap"]);
                        FileDelete(strMap, "GoogleMap");
                    }
                }

                K2.DeleteProjects(ID);

            }
            catch (Exception ex)
            {
            }
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
 "Swal.fire({ " +
 "  title: 'Deleted Successfully', " +
 "  text: 'Your project has been successfully deleted.', " +
 "  icon: 'success', " +
 "  confirmButtonText: 'OK' " +
 "}).then((result) => { " +
 "  if (result.isConfirmed) { " +
 "    window.location = 'view-project.aspx'; " + // Replace with your target page URL
 "  } " +
 "});", true);

        }
    }



    public void FileDelete(string ImageName, string appkey)
    {

        string filePath = HttpContext.Current.Server.MapPath(System.Configuration.ConfigurationManager.AppSettings[appkey]);
        filePath += "//" + ImageName.Trim();
        if (System.IO.File.Exists(filePath))
        {
            try
            {
                System.IO.File.Delete(filePath);

            }
            catch (System.IO.IOException e)
            {
                Console.WriteLine(e.Message);
                return;
            }
        }
    }




    protected string GetRowNo(string itemIndex)
    {
        return PageIndex > 1 ? (((PageIndex - 1) * 10) + Convert.ToInt32(itemIndex)).ToString() : itemIndex;
    }


    public int PageIndex
    {
        get { return ViewState["PageIndex"] != null ? (int)ViewState["PageIndex"] : 1; }
        set { ViewState["PageIndex"] = value; }
    }

    protected void lnkbtngo_Click(object sender, EventArgs e)
    {
        Bind();
    }

    protected void lnkcancel_Click(object sender, EventArgs e)
    {
        ddldisplaystatus.SelectedIndex = 0;
        ddlprojects.SelectedIndex = 0;
        ddlprojectstatus.SelectedIndex = 0;
        Bind();
    }

    protected void ddlprojects_SelectedIndexChanged(object sender, EventArgs e)
    {
        Bind();
    }

    protected void ddldisplaystatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        Bind();
    }

    protected void ddlprojectstatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        Bind();
    }






    protected void btnSubmitExport_Click(object sender, EventArgs e)
    {
        DataView LoanTable = new DataView();
        try
        {
            LoanTable = ((DataView)Session["ProjecTs"]);
            if (LoanTable != null && LoanTable.Count > 0)
            {
                DownloadToExcel();
            }
            else
            {
                string script = "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>" +
                                "<script>" +
                                "Swal.fire({" +
                                "title: 'No Records Found!'," +
                                "text: 'There are no records to export.'," +
                                "icon: 'warning'," +
                                "confirmButtonText: 'OK'" +
                                "});" +
                                "</script>";

                Page.ClientScript.RegisterStartupScript(this.GetType(), "SweetAlert", script);
            }
        }
        catch (Exception ex)
        {
        }
    }
    public void DownloadToExcel()
    {
        DataView LoanTable = new DataView();
        try
        {
            LoanTable = ((DataView)Session["Projects"]);
            if (LoanTable != null && LoanTable.Count > 0)
            {
                DataTable dt = new DataTable();
                dt = LoanTable.ToTable();
                dt1.Columns.Add("Sno");
                dt1.Columns.Add("Project Name");
                dt1.Columns.Add("Location");
                dt1.Columns.Add("Address");
                dt1.Columns.Add("State");
                dt1.Columns.Add("City");
                dt1.Columns.Add("No. of Blocks");
                dt1.Columns.Add("No. of Flats / Units");
                dt1.Columns.Add("Added On");



                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {

                    dr1 = dt1.NewRow();
                    string sno = (i + 1).ToString();
                    dr1["Sno"] = sno;
                    dr1["Project Name"] = dt.Rows[i]["ProjectName"].ToString();
                    dr1["Location"] = dt.Rows[i]["Location"].ToString();
                    dr1["Address"] = dt.Rows[i]["Address"].ToString();
                    dr1["State"] = BindState(Convert.ToInt32(dt.Rows[i]["State"]));
                    dr1["City"] = Bindcity(Convert.ToInt32(dt.Rows[i]["City"]));
                    dr1["No. of Blocks"] = dt.Rows[i]["BlockCount"].ToString();
                    dr1["No. of Flats / Units"] = dt.Rows[i]["FlatCount"].ToString();
                    DateTime dtDate = Convert.ToDateTime(dt.Rows[i]["Addeddate"]);
                    dr1["Added On"] = dtDate.ToString("dd/MM/yyyy");
                    dt1.Rows.Add(dr1);
                }
                ExportExcel(dt1);
            }
        }
        catch (Exception ex)
        {
        }
    }
    void ExportExcel(DataTable dt)
    {
        Response.ClearContent();
        Response.AddHeader("content-disposition", "attachment; filename=ProjectsDetails" + DateTime.Now.ToString("ddMMyyyy_hh:mm:ss") + ".xls");
        Response.ContentType = "application/ms-excel";
        string tab = "";
        foreach (DataColumn dc in dt.Columns)
        {
            Response.Write(tab + dc.ColumnName);
            tab = "\t";
        }
        Response.Write("\n");
        int i;
        foreach (DataRow dr in dt.Rows)
        {
            tab = "";
            for (i = 0; i < dt.Columns.Count; i++)
            {
                Response.Write(tab + dr[i].ToString());
                tab = "\t";
            }
            Response.Write("\n");
        }
        Response.End();

    }




















}