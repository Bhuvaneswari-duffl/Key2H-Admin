﻿using System;
using System.Activities.Expressions;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class adminkey2hcomaddflat : System.Web.UI.Page
{

    Key2hFlat KF = new Key2hFlat();
    Key2hProjectblock KB = new Key2hProjectblock();
    Key2hProject K2 = new Key2hProject();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            Bindprojects();

            if (Request.QueryString["FlatID"] != null)
            {
                lbldisplaymsg.Text = " Edit Flat";
                btnSave.Text = "Update";
                Bind(Convert.ToInt32(Request.QueryString["FlatID"]));


            }
            else
            {
                lbldisplaymsg.Text = " Add Flat";
                btnSave.Text = "Submit";
            }


        }
    }



    public void Bindprojects()
    {
        DataTable dt = K2.ViewActiveprojects();
        if (dt.Rows.Count > 0)
        {
            ddlProName.DataSource = dt;
            ddlProName.DataTextField = "ProjectName";
            ddlProName.DataValueField = "ProjectID";
            ddlProName.DataBind();
            ddlProName.Items.Insert(0, new ListItem("", ""));
        }
    }







    public void Bind(int id)
    {

        DataTable dt = KF.ViewAllBflat("", "", Convert.ToString(id),"");

        if (dt.Rows.Count > 0)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["ProjectID"])))
            {
                ddlProName.SelectedValue = Convert.ToString(dt.Rows[0]["ProjectID"]);
                Bindblock();
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["BlockID"])))
            {
                ddlBlockNumber.SelectedValue = Convert.ToString(dt.Rows[0]["BlockID"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["FlatName"])))
            {
                txtUnitNoFlatNo.Text = Convert.ToString(dt.Rows[0]["FlatName"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["Facing"])))
            {
                txtFacing.Text = Convert.ToString(dt.Rows[0]["Facing"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["UDS"])))
            {
                txtUDS.Text = Convert.ToString(dt.Rows[0]["UDS"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["UnitType"])))
            {
                txtUnitType.Text = Convert.ToString(dt.Rows[0]["UnitType"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["SaleableArea"])))
            {
                txtSaleableArea.Text = Convert.ToString(dt.Rows[0]["SaleableArea"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["CarpetArea"])))
            {
                txtCarpetArea.Text = Convert.ToString(dt.Rows[0]["CarpetArea"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["Balcony"])))
            {
                txtBalcony.Text = Convert.ToString(dt.Rows[0]["Balcony"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["Wallarea"])))
            {
                txtWallArea.Text = Convert.ToString(dt.Rows[0]["Wallarea"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["Floor"])))
            {
                ddlFloor.SelectedValue = Convert.ToString(dt.Rows[0]["Floor"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["CarparkingCount"])))
            {
                ddlNoOfCarParking.SelectedValue = Convert.ToString(dt.Rows[0]["CarparkingCount"]);


                if (ddlNoOfCarParking.SelectedValue == "1")
                {
                    divcarp1.Style.Add("display","block");
                }
                else if (ddlNoOfCarParking.SelectedValue == "2")
                {
                    divcarp1.Style.Add("display", "block");
                    divcarp2.Style.Add("display", "block");
                }
                else if (ddlNoOfCarParking.SelectedValue == "3")
                {
                    divcarp1.Style.Add("display", "block");
                    divcarp2.Style.Add("display", "block");
                    divcarp3.Style.Add("display", "block");

                }
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["Carparkslot1"])))
            {
                txtcarparking1.Text = Convert.ToString(dt.Rows[0]["Carparkslot1"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["Carparkslot2"])))
            {
                txtcarparking2.Text = Convert.ToString(dt.Rows[0]["Carparkslot2"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["Carparkslot3"])))
            {
                txtcarparking2.Text = Convert.ToString(dt.Rows[0]["Carparkslot3"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["FlatStatus"])))
            {
                bool status = Convert.ToBoolean(dt.Rows[0]["FlatStatus"]);

                if (status == true)
                {
                    toggleActiveInactive.Checked = true;
                }
                else
                {
                    toggleActiveInactive.Checked = false;
                }
            }
        }
    }






    protected void btnSave_Click(object sender, EventArgs e)
    {

        string labelerror = string.Empty;
        if (string.IsNullOrEmpty(ddlProName.SelectedValue) && string.IsNullOrEmpty(ddlBlockNumber.SelectedValue) &&
            string.IsNullOrEmpty(txtUnitNoFlatNo.Text) && string.IsNullOrEmpty(txtFacing.Text) &&
            string.IsNullOrEmpty(txtUDS.Text) && string.IsNullOrEmpty(txtUnitType.Text) &&
            string.IsNullOrEmpty(txtSaleableArea.Text) && string.IsNullOrEmpty(txtCarpetArea.Text) &&
            string.IsNullOrEmpty(txtBalcony.Text) && string.IsNullOrEmpty(txtWallArea.Text) &&
            string.IsNullOrEmpty(ddlFloor.SelectedValue) && string.IsNullOrEmpty(ddlNoOfCarParking.SelectedValue))
        {
            labelerror = "Fill all the field ";
        }
        else if (string.IsNullOrEmpty(ddlProName.SelectedValue))
        {
            labelerror = "Select project name";
        }
        else if (string.IsNullOrEmpty(ddlBlockNumber.SelectedValue))
        {
            labelerror = "Select block no.";
        }
        else if (string.IsNullOrEmpty(txtUnitNoFlatNo.Text))
        {
            labelerror = "Enter unit no./flat no.";
        }
        else if (string.IsNullOrEmpty(txtFacing.Text))
        {
            labelerror = "Enter facing";
        }
        else if (string.IsNullOrEmpty(txtUDS.Text))
        {
            labelerror = "Enter UDS";
        }
        else if (string.IsNullOrEmpty(txtUnitType.Text))
        {
            labelerror = "Enter unit type";
        }
        else if (string.IsNullOrEmpty(txtSaleableArea.Text))
        {
            labelerror = "Enter saleable area";
        }
        else if (string.IsNullOrEmpty(txtCarpetArea.Text))
        {
            labelerror = "Enter carpet area";
        }
        else if (string.IsNullOrEmpty(txtBalcony.Text))
        {
            labelerror = "Enter balcony";
        }
        else if (string.IsNullOrEmpty(txtWallArea.Text))
        {
            labelerror = "Enter wall area";
        }
        else if (string.IsNullOrEmpty(ddlFloor.SelectedValue))
        {
            labelerror = "Select floor";
        }
        else if (string.IsNullOrEmpty(ddlNoOfCarParking.SelectedValue))
        {
            labelerror = "Select no of car parking";
        }


        if (string.IsNullOrEmpty(labelerror))
        {
            if (Request.QueryString["FlatID"] == null)
            {
                if (!Isalreadyexist(ddlProName.SelectedValue, ddlBlockNumber.SelectedValue, txtUnitNoFlatNo.Text))


                {
                    int ret = 1;
                ret = AddData();
                if (ret == 1)
                {
                    Clear();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                 "Swal.fire('Added Successfully', 'Your flat details have been successfully added!.', 'success');", true);
                }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                         "Swal.fire({ " +
                          "  title: 'Flat Already Exists', " +
                          "  text: 'A flat with the same details already exists. Please check and try again.', " +
                          "  icon: 'warning', " +
                          "  confirmButtonText: 'OK', " +
                          "  confirmButtonColor: '#3085d6' " +
                          "});", true);
                }
            }
            else
            {
                int ret = 0;
                ret = UpdateData();
                if (ret == 1)
                {
                    Clear();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                    "Swal.fire({title: 'Updated Successfully', text: 'Your flat details have been successfully updated!', icon: 'success'}).then((result) => { if (result.isConfirmed) { window.location.href = 'view-flat.aspx'; } });",
                     true);
                }
            }
        }
        else
        {
            //alert labelerror
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                   "Swal.fire('Validation Alert', '" + labelerror + "!.', 'success');", true);
        }


    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();
        if (Request.QueryString["Projectid"] == null)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                  "Swal.fire('Cancelled!', 'Your action has been canceled.', 'success');",
                  true);
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
            "Swal.fire({title: 'Cancelled', text: 'Your action has been canceled.', icon: 'success'}).then((result) => { if (result.isConfirmed) { window.location.href = 'add-flat.aspx'; } });",
             true);
        }
    }



    public int AddData()
    {


        int ret = 0;
        try
        {
            KF.ProjectID = Convert.ToInt32(ddlProName.SelectedValue);
            KF.BlockID = Convert.ToInt32(ddlBlockNumber.SelectedValue);
            KF.FlatName = Convert.ToString(txtUnitNoFlatNo.Text);
            KF.Facing = txtFacing.Text;
            KF.UDS = txtUDS.Text;
            KF.UnitType = txtUnitType.Text;
            KF.SaleableArea = txtSaleableArea.Text;
            KF.CarpetArea = txtCarpetArea.Text;

            KF.Balcony = txtBalcony.Text;
            KF.Wallarea = txtWallArea.Text;
            KF.Floor = Convert.ToInt32(ddlFloor.SelectedValue);
            KF.CarparkingCount = Convert.ToInt32(ddlNoOfCarParking.SelectedValue);

            if (ddlNoOfCarParking.SelectedValue == "1")
            {
                KF.Carparkslot1 = txtcarparking1.Text;
                KF.Carparkslot2 = "";
                KF.Carparkslot3 = "";
            }
            else if (ddlNoOfCarParking.SelectedValue == "2")
            {
                KF.Carparkslot1 = txtcarparking1.Text;
                KF.Carparkslot2 = txtcarparking2.Text;
                KF.Carparkslot3 = "";
            }
            else if (ddlNoOfCarParking.SelectedValue == "3")
            {
                KF.Carparkslot1 = txtcarparking1.Text;
                KF.Carparkslot2 = txtcarparking2.Text;
                KF.Carparkslot3 = txtcarparking3.Text;
            }
            KF.FlatStatus = toggleActiveInactive.Checked;
            KF.AddedBy = "ADMIN";
            ret = KF.AddFlatdetails(KF);
        }
        catch (Exception ex)
        {

        }
        return ret;
    }


    public int UpdateData()
    {
        int ret = 0;
        try
        {
            KF.FlatID = Convert.ToInt32(Request.QueryString["FlatID"]);
            KF.ProjectID = Convert.ToInt32(ddlProName.SelectedValue);
            KF.BlockID = Convert.ToInt32(ddlBlockNumber.SelectedValue);
            KF.FlatName = Convert.ToString(txtUnitNoFlatNo.Text);
            KF.Facing = txtFacing.Text;
            KF.UDS = txtUDS.Text;
            KF.UnitType = txtUnitType.Text;
            KF.SaleableArea = txtSaleableArea.Text;
            KF.CarpetArea = txtCarpetArea.Text;

            KF.Balcony = txtBalcony.Text;
            KF.Wallarea = txtWallArea.Text;
            KF.Floor = Convert.ToInt32(ddlFloor.SelectedValue);
            KF.CarparkingCount = Convert.ToInt32(ddlNoOfCarParking.SelectedValue);

            if (ddlNoOfCarParking.SelectedValue == "1")
            {
                KF.Carparkslot1 = txtcarparking1.Text;
                KF.Carparkslot2 = "";
                KF.Carparkslot3 = "";
            }
            else if (ddlNoOfCarParking.SelectedValue == "2")
            {
                KF.Carparkslot1 = txtcarparking1.Text;
                KF.Carparkslot2 = txtcarparking2.Text;
                KF.Carparkslot3 = "";
            }
            else if (ddlNoOfCarParking.SelectedValue == "3")
            {
                KF.Carparkslot1 = txtcarparking1.Text;
                KF.Carparkslot2 = txtcarparking2.Text;
                KF.Carparkslot3 = txtcarparking3.Text;
            }
            KF.FlatStatus = toggleActiveInactive.Checked;
            KF.UpdatedBy = "ADMIN";
            ret = KF.UpdateFlatdetails(KF);
        }
        catch (Exception ex)
        {

        }
        return ret;
    }



    public void Clear()
    {
        ddlProName.SelectedIndex = 0;
        ddlBlockNumber.SelectedIndex = 0;
        txtUnitNoFlatNo.Text = "";
        txtFacing.Text = "";
        txtUDS.Text = "";
        txtUnitType.Text = "";
        txtSaleableArea.Text = "";
        txtCarpetArea.Text = "";
        txtBalcony.Text = "";
        txtWallArea.Text = "";
        ddlFloor.SelectedIndex = 0;
        ddlNoOfCarParking.SelectedIndex = 0;
        toggleActiveInactive.Checked = true;
        txtcarparking1.Text = "";
        txtcarparking2.Text = "";
        txtcarparking3.Text = "";
        ddlBlockNumber.Items.Clear();
        ddlBlockNumber.Items.Insert(0, new ListItem("", ""));
        //BindCity();

    }




    public bool Isalreadyexist(string PID,string BlockID, string Bname)
    {
        bool isavail = false;
        string strbname = string.Empty;
        DataTable dt = KF.AlreadyExistFlat(Convert.ToInt32(PID), Convert.ToInt32(BlockID), Bname);

        if (dt.Rows.Count > 0)
        {

            isavail = true;

        }

        return isavail;
    }



    protected void ddlProName_SelectedIndexChanged(object sender, EventArgs e)
    {

        Bindblock();
    }


    public void Bindblock()
    {

        if (!string.IsNullOrEmpty(ddlProName.SelectedValue))
        {
            DataTable DT = KB.ViewBlockbyProjectID(Convert.ToInt32(ddlProName.SelectedValue));

            if (DT.Rows.Count > 0)
            {
                ddlBlockNumber.DataSource = DT;
                ddlBlockNumber.DataTextField = "BlockName";
                ddlBlockNumber.DataValueField = "BlockID";
                ddlBlockNumber.DataBind();
                ddlBlockNumber.Items.Insert(0, new ListItem("", ""));
            }
            else
            {
                ddlBlockNumber.Items.Clear();
                ddlBlockNumber.Items.Insert(0, new ListItem("No Block number", ""));
            }
        }
        else
        {
            ddlBlockNumber.Items.Clear();
            ddlBlockNumber.Items.Insert(0, new ListItem("", ""));
        }
    }
}