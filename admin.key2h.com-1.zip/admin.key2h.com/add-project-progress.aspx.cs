﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class adminkey2hcomaddprojectprogress : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {

        string labelerror = string.Empty;
        if (string.IsNullOrEmpty(ddlprojects.SelectedValue) && string.IsNullOrEmpty(ddlmonth.SelectedValue) &&
            string.IsNullOrEmpty(ddlyear.SelectedValue))
        {
            labelerror = "Fill all the filed";
        }
        else if (string.IsNullOrEmpty(ddlprojects.SelectedValue))
        {
            labelerror = "Select project name";
        }
        else if (string.IsNullOrEmpty(ddlmonth.SelectedValue))
        {
            labelerror = "Select month";
        }
        else if (string.IsNullOrEmpty(ddlyear.SelectedValue))
        {
            labelerror = "Select year";
        }
         


        if (string.IsNullOrEmpty(labelerror))
        {
            if (Request.QueryString["Projectid"] == null)
            {

                int ret = 1;
                //ret = AddData();
                if (ret == 1)
                {
                    Clear();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                 "Swal.fire('Added Successfully', 'Your project progress details have been successfully added!.', 'success');", true);
                }

            }
            else
            {
                int ret = 0;
                //ret = UpdateData();
                if (ret == 1)
                {
                    //Clear();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                    "Swal.fire({title: 'Updated Successfully', text: 'Your project progress details have been successfully updated!', icon: 'success'}).then((result) => { if (result.isConfirmed) { window.location.href = 'view-project-progress.aspx'; } });",
                     true);
                }
            }
        }
        else
        {
            //alert labelerror
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                   "Swal.fire('Validation Alert', '" + labelerror + "!.', 'success');", true);
        }


    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();
        if (Request.QueryString["Projectid"] == null)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                  "Swal.fire('Cancelled!', 'Your action has been canceled.', 'success');",
                  true);
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
            "Swal.fire({title: 'Cancelled', text: 'Your action has been canceled.', icon: 'success'}).then((result) => { if (result.isConfirmed) { window.location.href = 'add-project-progress.aspx'; } });",
             true);
        }
    }



    public void Clear()
    { 
            ddlprojects.SelectedIndex = 0;
            ddlmonth.SelectedIndex = 0;
            ddlyear.SelectedIndex = 0;
            toggleActiveInactive.Checked = true;

        //BindCity();

    }
}