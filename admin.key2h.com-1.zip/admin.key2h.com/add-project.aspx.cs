﻿
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



public partial class adminkey2hcom_Addproject : System.Web.UI.Page
{
    Key2hProject K2 = new Key2hProject();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            hdnclentid.Value = "1";
            BindState();
            if (Request.QueryString["Projectid"] != null)
            {
                //edit
                btnSave.Text = "Update";
                lbldisplaystatus.Text = "Edit Project";
                Bind(Convert.ToInt32(Request.QueryString["Projectid"]));

            }
            else
            {
                lbldisplaystatus.Text = "Add Project";
                btnSave.Text = "Submit";
                //add
            }
        }


    }


    protected void ddlstate_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(ddlstate.SelectedValue))
        {
            BindCity();
        }
        else
        {
            ddlcity.Items.Clear();
            ddlcity.Items.Insert(0, new ListItem("", ""));
            ddlcity.Items.Insert(1, new ListItem("Select State", ""));
        }

    }



    public void BindCity()
    {
        if (!string.IsNullOrEmpty(ddlstate.SelectedValue))
        {
            DataTable dt = K2.ViewAllcityByStateid(Convert.ToInt32(ddlstate.SelectedValue));
            if (dt.Rows.Count > 0)
            {
                ddlcity.DataSource = dt;
                ddlcity.DataTextField = "CityName";
                ddlcity.DataValueField = "CityID";
                ddlcity.DataBind();
                ddlcity.Items.Insert(0, new ListItem("", ""));
            }
            else
            {
                ddlcity.Items.Clear();
                ddlcity.Items.Insert(0, new ListItem("", ""));
                ddlcity.Items.Insert(1, new ListItem("Select State", ""));
            }
        }
        else
        {
            ddlcity.Items.Clear();
            ddlcity.Items.Insert(0, new ListItem("", ""));
            ddlcity.Items.Insert(1, new ListItem("Select State", ""));
        }

    }


    public void BindState()
    {
        DataTable dt = K2.ViewAllstate();
        if (dt.Rows.Count > 0)
        {
            ddlstate.DataSource = dt;
            ddlstate.DataTextField = "StateName";
            ddlstate.DataValueField = "StateID";
            ddlstate.DataBind();
            ddlstate.Items.Insert(0, new ListItem("", ""));
        }
    }




    public void Bind(int id)
    {
        DataTable dt = K2.ViewAllProjectsByid(id);

        RequiredFieldValidator1.Visible = false;
        RequiredFieldValidator14.Visible = false;
        RequiredFieldValidator15.Visible = false;
        viewprobtn.Style["top"] = "5px";
        viewproscreenbtn.Style["top"] = "5px";
        viewmapbtn.Style["top"] = "5px";



        if (dt.Rows.Count > 0)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["ProjectLogo"])))
            {
                hdnProjectlogo.Value = Convert.ToString(dt.Rows[0]["ProjectLogo"]);
                string filepath = System.Configuration.ConfigurationManager.AppSettings["Logo"];
                string fullFilePath = Path.Combine(filepath.Trim(), hdnProjectlogo.Value);
                string fileUrl = fullFilePath;
                string formattedImagePath = HttpUtility.JavaScriptStringEncode(fileUrl);
                string script = string.Format("var srclogo = '{0}'; bindImageToPreview(srclogo);", formattedImagePath);
                ClientScript.RegisterStartupScript(this.GetType(), "bindImage", script, true);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["ProjectName"])))
            {
                txtprojectname.Text = Convert.ToString(dt.Rows[0]["ProjectName"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["Location"])))
            {
                txtlocation.Text = Convert.ToString(dt.Rows[0]["Location"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["Address"])))
            {
                txtAddress.Text = Convert.ToString(dt.Rows[0]["Address"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["State"])))
            {
                ddlstate.SelectedValue = Convert.ToString(dt.Rows[0]["State"]);

            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["City"])))
            {
                ddlcity.SelectedValue = Convert.ToString(dt.Rows[0]["City"]);
                BindCity();
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["PostalCode"])))
            {
                txtpostalcode.Text = Convert.ToString(dt.Rows[0]["PostalCode"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["GoogleMapLink"])))
            {
                txtGooglemap.Text = Convert.ToString(dt.Rows[0]["GoogleMapLink"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["BlockCount"])))
            {
                txtnoofblocks.Text = Convert.ToString(dt.Rows[0]["BlockCount"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["FlatCount"])))
            {
                txtflatsunits.Text = Convert.ToString(dt.Rows[0]["FlatCount"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["LandArea"])))
            {
                txtlandarea.Text = Convert.ToString(dt.Rows[0]["LandArea"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["RERANumber"])))
            {
                txtreranumber.Text = Convert.ToString(dt.Rows[0]["RERANumber"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["ProjectStatus"])))
            {
                ddlProjectstatus.SelectedValue = Convert.ToString(dt.Rows[0]["ProjectStatus"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["ProjectDisplayStatus"])))
            {
                bool istrue = Convert.ToBoolean(dt.Rows[0]["ProjectDisplayStatus"]);
                if (istrue)
                {
                    toggleActiveInactive.Checked = true;
                }
                else
                {
                    toggleActiveInactive.Checked = false;
                }
            }



            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["ProjectStatusPercentage"])))
            {
                txtProjectstatus.Text = Convert.ToString(dt.Rows[0]["ProjectStatusPercentage"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["SplashScreenImage"])))
            {
                hdnprojectscreen.Value = Convert.ToString(dt.Rows[0]["SplashScreenImage"]);
                string filepath1 = System.Configuration.ConfigurationManager.AppSettings["ProjectScreen"];
                string fullFilePath1 = Path.Combine(filepath1, hdnprojectscreen.Value);
                string fileUrl1 = fullFilePath1;
                string formattedImagePath1 = HttpUtility.JavaScriptStringEncode(fileUrl1);
                // Safely construct the script string
                string script1 = string.Format(
                    "var proimg = '{0}'; bindImageToPreviewSplashScreenImage(proimg);",
                    formattedImagePath1
                );
                ClientScript.RegisterStartupScript(this.GetType(), "ProjectScreen", script1, true);
            }










            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["LocationMap"])))
            {
                hdnuploadlocationmap.Value = Convert.ToString(dt.Rows[0]["LocationMap"]);
                string filepath2 = System.Configuration.ConfigurationManager.AppSettings["GoogleMap"];
                string fullFilePath2 = Path.Combine(filepath2, hdnuploadlocationmap.Value);
                string fileUrl2 = fullFilePath2;
                string formattedImagePath2 = HttpUtility.JavaScriptStringEncode(fileUrl2);
                // Safely construct the script string
                string script2 = string.Format(
                    "var srcmap = '{0}'; bindImageToPreviewlocationmap(srcmap);",
                    formattedImagePath2
                );
                ClientScript.RegisterStartupScript(this.GetType(), "locationmap", script2, true);
            }


            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["BankName"])))
            {
                txtBankname.Text = Convert.ToString(dt.Rows[0]["BankName"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["AccountName"])))
            {
                txtaccountname.Text = Convert.ToString(dt.Rows[0]["AccountName"]);
            }
            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["IFSCNumber"])))
            {
                txtifscnumber.Text = Convert.ToString(dt.Rows[0]["IFSCNumber"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["BranchName"])))
            {
                txtBranch.Text = Convert.ToString(dt.Rows[0]["BranchName"]);
            }

            if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["AccountNumber"])))
            {
                txtaccountnumber.Text = Convert.ToString(dt.Rows[0]["AccountNumber"]);
            }
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {

        string labelerror = string.Empty;
        if (string.IsNullOrEmpty(txtprojectname.Text) && string.IsNullOrEmpty(txtlocation.Text) && string.IsNullOrEmpty(txtAddress.Text) && string.IsNullOrEmpty(ddlstate.SelectedValue) &&
            string.IsNullOrEmpty(ddlcity.SelectedValue) && string.IsNullOrEmpty(txtpostalcode.Text) && string.IsNullOrEmpty(txtGooglemap.Text) && string.IsNullOrEmpty(txtnoofblocks.Text) && string.IsNullOrEmpty(txtflatsunits.Text) &&
            string.IsNullOrEmpty(txtlandarea.Text) && string.IsNullOrEmpty(txtreranumber.Text) && string.IsNullOrEmpty(ddlProjectstatus.SelectedValue) && string.IsNullOrEmpty(txtProjectstatus.Text)
            && string.IsNullOrEmpty(txtBankname.Text) && string.IsNullOrEmpty(txtaccountname.Text) && string.IsNullOrEmpty(txtaccountnumber.Text) && string.IsNullOrEmpty(txtifscnumber.Text) && string.IsNullOrEmpty(txtBranch.Text))
        {
            labelerror = "Fill all the filed";
        }
        else if (string.IsNullOrEmpty(txtprojectname.Text))
        {
            labelerror = "Enter project name";
        }
        else if (string.IsNullOrEmpty(txtlocation.Text))
        {
            labelerror = "Enter location";
        }
        else if (string.IsNullOrEmpty(txtAddress.Text))
        {
            labelerror = "Enter address";
        }
        else if (string.IsNullOrEmpty(ddlstate.SelectedValue))
        {
            labelerror = "Select state";
        }
        else if (string.IsNullOrEmpty(ddlcity.SelectedValue))
        {
            labelerror = "select city";
        }
        else if (string.IsNullOrEmpty(txtpostalcode.Text))
        {
            labelerror = "Enter Postal code";
        }
        else if (string.IsNullOrEmpty(txtGooglemap.Text))
        {
            labelerror = "Enter google map";
        }
        else if (string.IsNullOrEmpty(txtnoofblocks.Text))
        {
            labelerror = "Enter no of blocks";
        }
        else if (string.IsNullOrEmpty(txtflatsunits.Text))
        {
            labelerror = "Enter flats/units";
        }
        else if (string.IsNullOrEmpty(txtlandarea.Text))
        {
            labelerror = "Enter landarea";
        }
        else if (string.IsNullOrEmpty(txtreranumber.Text))
        {
            labelerror = "Enter rera number";
        }
        else if (string.IsNullOrEmpty(ddlProjectstatus.SelectedValue))
        {
            labelerror = "Select project status";
        }
        else if (string.IsNullOrEmpty(txtBankname.Text))
        {
            labelerror = "Enter bank name";
        }
        else if (string.IsNullOrEmpty(txtaccountname.Text))
        {
            labelerror = "Enter account name";
        }
        else if (string.IsNullOrEmpty(txtaccountnumber.Text))
        {
            labelerror = "Enter account number";
        }
        else if (string.IsNullOrEmpty(txtifscnumber.Text))
        {
            labelerror = "Enter IFSC number";
        }
        else if (string.IsNullOrEmpty(txtBranch.Text))
        {
            labelerror = "Enter branch";
        }


        if (string.IsNullOrEmpty(labelerror))
        {
            if (Request.QueryString["Projectid"] == null)
            {
                if (!IsAlreadyexist(txtprojectname.Text, 1)) //Set the default client ID. But originally,got the ID based on login details.
                {
                    int ret = 0;
                    ret = AddData();
                    if (ret == 1)
                    {
                        Clear();
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                     "Swal.fire('Added Successfully', 'Your project details have been successfully added!.', 'success');", true);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                         "Swal.fire({ " +
                          "  title: 'Project Already Exists', " +
                          "  text: 'A project with the same details already exists. Please check and try again.', " +
                          "  icon: 'warning', " +
                          "  confirmButtonText: 'OK', " +
                          "  confirmButtonColor: '#3085d6' " +
                          "});", true);
                }
            }
            else
            {
                int ret = 0;
                ret = UpdateData();
                if (ret == 1)
                {
                    Clear();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                    "Swal.fire({title: 'Updated Successfully', text: 'Your project details have been successfully updated!', icon: 'success'}).then((result) => { if (result.isConfirmed) { window.location.href = 'view-project.aspx'; } });",
                     true);
                }
            }
        }
        else
        {
            //alert labelerror
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                   "Swal.fire('Validation Alert', '" + labelerror + "!.', 'success');", true);
        }
    }




    public bool IsAlreadyexist(string Project, int clientID)
    {
        bool isavail = false;
        DataTable dt = K2.AlreadyExistProjectNamebyClientID(clientID);
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (string.Equals(Convert.ToString(dt.Rows[i]["ProjectName"]).ToLower().Replace(" ",""), Project.ToLower().Replace(" ", ""), StringComparison.Ordinal))
                {
                    isavail = true;
                }
            }
        }
        return isavail;
    }



    public int AddData()
    {
        //get login client id after pass this proberties
        K2.ClientID = 1;//i set default
        K2.ProjectName = txtprojectname.Text;
        K2.ProjectLogo = SaveFile(UploadProjectlogo, "Logo", txtprojectname.Text);
        K2.Location = txtlocation.Text;
        K2.Address = txtAddress.Text;
        K2.State = Convert.ToInt32(ddlstate.SelectedValue);
        K2.City = Convert.ToInt32(ddlcity.SelectedValue);
        K2.PostalCode = Convert.ToInt32(txtpostalcode.Text);
        K2.GoogleMapLink = txtGooglemap.Text;
        K2.BlockCount = Convert.ToInt32(txtnoofblocks.Text);
        K2.FlatCount = Convert.ToInt32(txtflatsunits.Text);
        K2.LandArea = txtlandarea.Text;
        K2.RERANumber = txtlandarea.Text;
        K2.ProjectStatus = Convert.ToInt32(ddlProjectstatus.Text);
        K2.ProjectDisplayStatus = toggleActiveInactive.Checked;
        K2.ProjectStatusPercentage = Convert.ToInt32(txtProjectstatus.Text);
        K2.SplashScreenImage = SaveFile(FluploadProjectScreen, "ProjectScreen", txtprojectname.Text);
        K2.LocationMap = SaveFile(Fileuploadlocationmap, "GoogleMap", txtprojectname.Text);
        K2.BankName = txtBankname.Text;
        K2.AccountName = txtaccountname.Text;
        K2.AccountNumber = txtaccountnumber.Text;
        K2.IFSCNumber = txtifscnumber.Text;
        K2.BranchName = txtBranch.Text;
        K2.AddedBy = "Admin dashboard";
        int ret = 0;
        ret = K2.AddPROJECTS(K2);
        return ret;
    }


    public int UpdateData()
    {
        //get login client id after pass this proberties
        K2.ProjectID = Convert.ToInt32(Request.QueryString["Projectid"]);
        K2.ClientID = 1;//i set default
        K2.ProjectName = txtprojectname.Text;
        if (!UploadProjectlogo.HasFile)
        {
            K2.ProjectLogo = hdnProjectlogo.Value;
        }
        else
        {
            K2.ProjectLogo = SaveFile(UploadProjectlogo, "Logo", txtprojectname.Text);
        }
        K2.Location = txtlocation.Text;
        K2.Address = txtAddress.Text;
        K2.State = Convert.ToInt32(ddlstate.SelectedValue);
        K2.City = Convert.ToInt32(ddlcity.SelectedValue);
        K2.PostalCode = Convert.ToInt32(txtpostalcode.Text);
        K2.GoogleMapLink = txtGooglemap.Text;
        K2.BlockCount = Convert.ToInt32(txtnoofblocks.Text);
        K2.FlatCount = Convert.ToInt32(txtflatsunits.Text);
        K2.LandArea = txtlandarea.Text;
        K2.RERANumber = txtlandarea.Text;
        K2.ProjectStatus = Convert.ToInt32(ddlProjectstatus.Text);
        K2.ProjectDisplayStatus = toggleActiveInactive.Checked;
        K2.ProjectStatusPercentage = Convert.ToInt32(txtProjectstatus.Text);
        if (FluploadProjectScreen.HasFile)
        {
            K2.SplashScreenImage = SaveFile(FluploadProjectScreen, "ProjectScreen", txtprojectname.Text);
        }
        else
        {
            K2.SplashScreenImage = hdnprojectscreen.Value;
        }
        if (Fileuploadlocationmap.HasFile)
        {
            K2.LocationMap = SaveFile(Fileuploadlocationmap, "GoogleMap", txtprojectname.Text);
        }
        else
        {
            K2.LocationMap = hdnuploadlocationmap.Value;
        }
        K2.BankName = txtBankname.Text;
        K2.AccountName = txtaccountname.Text;
        K2.AccountNumber = txtaccountnumber.Text;
        K2.IFSCNumber = txtifscnumber.Text;
        K2.BranchName = txtBranch.Text;
        K2.UpdatedBy = "Admin dashboard";
        int ret = 0;
        ret = K2.UpdatePROJECTS(K2);
        return ret;
    }




    public string SaveFile(FileUpload uploadedFile, string appkey, string Projectname)
    {
        int savefile = 0;
        string filename = string.Empty;
        try
        {


            string filepath = System.Configuration.ConfigurationManager.AppSettings[appkey];
            string fileName = Path.GetFileName(uploadedFile.FileName);
            string fileExtension = Path.GetExtension(fileName);
            filename = GenerateFileName(Projectname.Trim(), fileExtension).Trim('-');
            string temppath = filepath.Trim() + @"\" + filename.Trim().Replace(" ", "");
            string savepath = Server.MapPath(temppath);
            uploadedFile.SaveAs(savepath);

            savefile = 1;
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }

        return filename.Replace(" ", "");
    }

    public string GenerateFileName(string Projectname, string fileExtension)
    {
        string randomString = GenerateRandomString(4);
        string newFileName = Projectname + randomString + fileExtension;
        return newFileName;
    }

    private string GenerateRandomString(int length)
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        var byteArray = new byte[length];
        using (var rng = RandomNumberGenerator.Create())
        {
            rng.GetBytes(byteArray);
        }

        var randomString = new char[length];
        for (int i = 0; i < length; i++)
        {
            randomString[i] = chars[byteArray[i] % chars.Length];
        }

        return new string(randomString);
    }



    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();
        if (Request.QueryString["Projectid"] == null)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                  "Swal.fire('Cancelled!', 'Your action has been canceled.', 'success');",
                  true);
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
            "Swal.fire({title: 'Cancelled', text: 'Your action has been canceled.', icon: 'success'}).then((result) => { if (result.isConfirmed) { window.location.href = 'add-project.aspx'; } });",
             true);
        }
    }



    public void Clear()
    {
        RequiredFieldValidator1.Visible = true;
        RequiredFieldValidator14.Visible = true;
        RequiredFieldValidator15.Visible = true;
        txtprojectname.Text = "";
        txtlocation.Text = "";
        txtAddress.Text = "";
        ddlstate.SelectedIndex = 0;
        ddlcity.SelectedIndex = 0;
        txtpostalcode.Text = "";
        txtGooglemap.Text = "";
        txtnoofblocks.Text = "";
        txtflatsunits.Text = "";
        txtlandarea.Text = "";
        txtreranumber.Text = "";
        txtProjectstatus.Text = "";
        ddlProjectstatus.SelectedIndex = 0;
        txtBankname.Text = "";
        txtaccountname.Text = "";
        txtaccountnumber.Text = "";
        txtifscnumber.Text = "";
        txtBranch.Text = "";
        toggleActiveInactive.Checked = true;

        ddlstate.SelectedIndex = 0;
        BindCity();

    }







    [System.Web.Services.WebMethod]
    public static bool CheckProjectExistence(int clientID, string projectName)
    {

        Key2hProject K2=new Key2hProject();
        bool exists = false;

        DataTable dt = K2.AlreadyExistProjectNamebyClientID(clientID);
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (string.Equals(Convert.ToString(dt.Rows[i]["ProjectName"]).ToLower().Replace(" ",""), projectName.ToLower().Replace(" ",""), StringComparison.Ordinal))
                {
                    exists = true;
                }
            }
        }

        return exists;
    }



}